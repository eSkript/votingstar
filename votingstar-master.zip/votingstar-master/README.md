# VotingStar

Adds named counters to WordPress. Use the shortcode `[votingstar id="star1" /]` to add a star with a number anywhere in your post. The star will act similar to a "like button": Every user will have one vote per id, and can remove the vote by clicking agin. 

The stars are only shown to logged in users. Admins can download a list with number of votes per id. The votes can also be backed up and restored. 
